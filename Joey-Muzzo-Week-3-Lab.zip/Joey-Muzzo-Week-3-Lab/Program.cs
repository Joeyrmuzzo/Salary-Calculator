﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Joey_Muzzo_Week_3_Lab
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
